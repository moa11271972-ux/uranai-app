# 大阪市 介護営業ルートアプリ

地域包括支援センター・居宅介護支援事業所向けの営業アプリです。

iPhone対応：Safariで開いて「共有」→「ホーム画面に追加」。現在地機能はHTTPS公開時に利用できます。

## 起動

```bash
npm install
npm run dev
```

## 公開

VercelにアップロードするとiPhoneからURLで使えます。

- Build command: `npm run build`
- Output directory: `dist`

## 主な機能

- 電話
- Googleマップ地図
- 現在地からルート
- 近い順表示
- 訪問ルート作成
- 訪問記録
- 写真登録
- CSV取込/出力
- ブラウザ自動保存
